Tesseract brand kit v1.0 (October 2026)

logos/     Full logo, T4 logo, symbol and wordmarks. SVG (vector), PNG (transparent), PDF (vector).
graphics/  Pattern, neon outline symbol, single-line symbol.
motion/    The build: MP4, GIF, transparent WebM, animated SVG.
colors/    ASE (Adobe), CSS, JSON, CSV. "official" values come from the logo files; "supporting" are interface colors.
fonts/     Manrope TTF, SIL Open Font License.

Use the -dark files on dark backgrounds and -light / -ink files on light backgrounds.
