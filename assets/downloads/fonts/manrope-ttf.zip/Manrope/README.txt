Manrope (Latin subset) by Mikhail Sharanda, SIL Open Font License 1.1.
The complete family with Cyrillic and other scripts is at https://fonts.google.com/specimen/Manrope
